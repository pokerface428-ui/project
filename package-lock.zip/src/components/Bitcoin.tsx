import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Plus, Trash2, Edit2, X, Search, Filter,
  RefreshCw, ExternalLink, Clock, AlertCircle,
  Newspaper, TrendingUp, ChevronDown, ChevronUp,
  Wifi, WifiOff, BarChart3, Bitcoin as BtcIcon
} from 'lucide-react';
import { BtcTrade } from '../types';
import { generateId, formatNumber } from '../utils/helpers';

interface BitcoinProps {
  trades: BtcTrade[];
  onSaveTrade: (trade: BtcTrade) => void;
  onDeleteTrade: (id: string) => void;
  /** App에서 전달되는 전역 다크모드 상태 */
  isDark?: boolean;
}

type SubTab = 'chart' | 'news' | 'journal';

// ===== COIN LIST =====
const COINS = [
  { symbol: 'BTC', name: '비트코인', tradingview: 'UPBIT:BTCKRW' },
  { symbol: 'ETH', name: '이더리움', tradingview: 'UPBIT:ETHKRW' },
  { symbol: 'XRP', name: '리플', tradingview: 'UPBIT:XRPKRW' },
  { symbol: 'SOL', name: '솔라나', tradingview: 'UPBIT:SOLKRW' },
  { symbol: 'DOGE', name: '도지코인', tradingview: 'UPBIT:DOGEKRW' },
  { symbol: 'ADA', name: '에이다', tradingview: 'UPBIT:ADAKRW' },
  { symbol: 'AVAX', name: '아발란체', tradingview: 'UPBIT:AVAXKRW' },
  { symbol: 'DOT', name: '폴카닷', tradingview: 'UPBIT:DOTKRW' },
];

// ===== UPBIT CHART =====
function UpbitChart({ isDark }: { isDark: boolean }) {
  const [selectedCoin, setSelectedCoin] = useState(COINS[0]);
  const chartRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!chartRef.current) return;
    chartRef.current.innerHTML = '';
    const script = document.createElement('script');
    script.src = 'https://s3.tradingview.com/tv.js';
    script.async = true;
    script.onload = () => {
      if (typeof (window as any).TradingView !== 'undefined' && chartRef.current) {
        new (window as any).TradingView.widget({
          container_id: chartRef.current.id,
          symbol: selectedCoin.tradingview,
          interval: '60',
          timezone: 'Asia/Seoul',
          theme: isDark ? 'dark' : 'light',
          style: '1',
          locale: 'kr',
          toolbar_bg: isDark ? '#0b1220' : '#f1f3f6',
          enable_publishing: false,
          allow_symbol_change: true,
          autosize: true,
          hide_side_toolbar: false,
          studies: ['MASimple@tv-basicstudies', 'Volume@tv-basicstudies'],
        });
      }
    };
    document.head.appendChild(script);
    return () => {
      try { document.head.removeChild(script); } catch { /* ignore */ }
    };
  }, [selectedCoin, isDark]);

  return (
    <div className="space-y-4">
      {/* Coin selector */}
      <div className="flex flex-wrap gap-2">
        {COINS.map(coin => (
          <button
            key={coin.symbol}
            onClick={() => setSelectedCoin(coin)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-bold transition-all ${
              selectedCoin.symbol === coin.symbol
                ? 'bg-gradient-to-r from-orange-400 to-amber-500 text-white shadow-lg shadow-orange-200'
                : 'bg-white border border-gray-200 text-gray-600 hover:bg-orange-50 hover:border-orange-300'
            }`}
          >
            <BtcIcon className="w-3.5 h-3.5" />
            {coin.symbol}
            <span className="text-[10px] opacity-70">{coin.name}</span>
          </button>
        ))}
      </div>

      {/* Chart */}
      <div className="bg-white dark:bg-slate-950/40 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-800/60 overflow-hidden">
        <div className="p-4 border-b border-gray-100 dark:border-slate-800/60">
          <h3 className="font-bold text-gray-800 dark:text-slate-100 flex items-center gap-2">
            📈 {selectedCoin.name} ({selectedCoin.symbol}/KRW) 실시간 차트
          </h3>
          <p className="text-xs text-gray-400 dark:text-slate-400 mt-1">TradingView · 업비트 원화 마켓</p>
        </div>
        <div id="tradingview-chart" ref={chartRef} className="w-full" style={{ height: '500px' }} />
      </div>

      {/* Quick links */}
      <div className="flex flex-wrap gap-2">
        <a href={`https://upbit.com/exchange?code=CRIX.UPBIT.KRW-${selectedCoin.symbol}`} target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-50 text-blue-600 text-sm font-bold hover:bg-blue-100 transition-colors">
          <ExternalLink className="w-3.5 h-3.5" /> 업비트에서 보기
        </a>
        <a href={`https://www.coingecko.com/ko/coins/${selectedCoin.name.toLowerCase()}`} target="_blank" rel="noopener noreferrer"
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-green-50 text-green-600 text-sm font-bold hover:bg-green-100 transition-colors">
          <ExternalLink className="w-3.5 h-3.5" /> CoinGecko
        </a>
      </div>
    </div>
  );
}

// ===== BITCOIN NEWS =====
interface CryptoNewsItem {
  title: string;
  link: string;
  pubDate: string;
  source: string;
  parsedDate: number;
}

const CRYPTO_KEYWORDS = [
  '비트코인', '이더리움', '리플', '암호화폐', '가상화폐', '가상자산', '코인',
  'BTC', 'ETH', 'XRP', '업비트', '빗썸', '바이낸스', '코인베이스',
  '블록체인', '디파이', 'DeFi', 'NFT', '스테이킹', '채굴', '마이닝',
  '반감기', '알트코인', '김치프리미엄', '크립토', 'crypto',
  '비트', '도지코인', '솔라나', '에이다', '토큰', '디지털자산',
  '가상통화', '코인시장', '코인거래', 'SEC', 'ETF승인',
  '비트코인ETF', '테더', 'USDT', '스테이블코인',
  '웹3', 'Web3', '메타버스', '탈중앙화',
];

function isCryptoRelated(title: string): boolean {
  const lower = title.toLowerCase();
  return CRYPTO_KEYWORDS.some(kw => lower.includes(kw.toLowerCase()));
}

function parseDate(dateStr: string): number {
  if (!dateStr) return 0;
  try {
    const d = new Date(dateStr);
    if (!isNaN(d.getTime())) return d.getTime();
    return 0;
  } catch { return 0; }
}

function timeAgo(ts: number): string {
  if (!ts) return '';
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  const h = Math.floor(diff / 3600000);
  const d = Math.floor(diff / 86400000);
  if (m < 1) return '방금 전';
  if (m < 60) return `${m}분 전`;
  if (h < 24) return `${h}시간 전`;
  if (d < 7) return `${d}일 전`;
  return new Date(ts).toLocaleDateString('ko-KR');
}

function CryptoNewsFeed() {
  const [news, setNews] = useState<CryptoNewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const fetchNews = useCallback(async (isManual = false) => {
    if (isManual) setIsRefreshing(true);
    else if (!lastUpdated) setLoading(true);

    const sources = [
      { url: 'https://news.google.com/rss/search?q=비트코인+암호화폐+코인&hl=ko&gl=KR&ceid=KR:ko', name: 'Google' },
      { url: 'https://news.google.com/rss/search?q=cryptocurrency+bitcoin+ethereum&hl=ko&gl=KR&ceid=KR:ko', name: 'Google2' },
    ];

    const collected: CryptoNewsItem[] = [];

    for (const source of sources) {
      try {
        // rss2json
        const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(source.url)}`;
        const res = await fetch(apiUrl, { signal: AbortSignal.timeout(8000) });
        if (!res.ok) continue;
        const data = await res.json();
        if (data.status !== 'ok' || !data.items) continue;
        data.items.forEach((item: any) => {
          const title = (item.title || '').replace(/<[^>]*>/g, '').trim();
          const pubDate = item.pubDate || '';
          collected.push({
            title,
            link: item.link || '',
            pubDate,
            source: item.author || source.name,
            parsedDate: parseDate(pubDate),
          });
        });
      } catch {
        // Try proxy
        try {
          const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(source.url)}`;
          const res = await fetch(proxyUrl, { signal: AbortSignal.timeout(8000) });
          if (!res.ok) continue;
          const xmlText = await res.text();
          const parser = new DOMParser();
          const doc = parser.parseFromString(xmlText, 'text/xml');
          doc.querySelectorAll('item').forEach(item => {
            const title = item.querySelector('title')?.textContent?.trim() || '';
            const link = item.querySelector('link')?.textContent?.trim() || '';
            const pubDate = item.querySelector('pubDate')?.textContent?.trim() || '';
            if (title) {
              collected.push({
                title: title.replace(/<[^>]*>/g, ''),
                link,
                pubDate,
                source: item.querySelector('source')?.textContent?.trim() || source.name,
                parsedDate: parseDate(pubDate),
              });
            }
          });
        } catch { /* skip */ }
      }
    }

    // Deduplicate
    const seen = new Set<string>();
    const unique = collected.filter(item => {
      const key = item.title.substring(0, 20).toLowerCase().replace(/\s/g, '');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    // Filter crypto only
    const cryptoOnly = unique.filter(item => isCryptoRelated(item.title));

    // Sort by date
    const sorted = (cryptoOnly.length > 0 ? cryptoOnly : unique)
      .sort((a, b) => b.parsedDate - a.parsedDate)
      .slice(0, 15);

    if (sorted.length > 0) {
      setNews(sorted);
      setLastUpdated(new Date());
      setError(null);
    } else {
      setError('암호화폐 뉴스를 불러올 수 없습니다.');
    }

    setLoading(false);
    setIsRefreshing(false);
  }, [lastUpdated]);

  useEffect(() => {
    fetchNews();
    const interval = setInterval(() => fetchNews(), 60000);
    return () => clearInterval(interval);
  }, []); // eslint-disable-line

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between p-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-100 rounded-xl">
            <Newspaper className="w-5 h-5 text-orange-600" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-gray-800">📰 암호화폐 최신 뉴스</h3>
            <div className="flex items-center gap-2 mt-1">
              {lastUpdated ? (
                <span className="flex items-center gap-1 text-[10px] text-green-500">
                  <Wifi className="w-3 h-3" />{lastUpdated.toLocaleTimeString('ko-KR')} 업데이트
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[10px] text-gray-400">
                  <WifiOff className="w-3 h-3" />연결 중...
                </span>
              )}
              <span className="text-[10px] text-gray-300">• 1분 자동갱신</span>
            </div>
          </div>
        </div>
        <button onClick={() => fetchNews(true)} disabled={isRefreshing}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
            isRefreshing ? 'bg-gray-100 text-gray-400' : 'bg-orange-50 text-orange-600 hover:bg-orange-100'
          }`}>
          <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? '갱신중' : '새로고침'}
        </button>
      </div>

      {/* Content */}
      <div className="divide-y divide-gray-50">
        {loading && news.length === 0 ? (
          <div className="p-5 space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="animate-pulse flex gap-3">
                <div className="w-8 h-8 bg-gray-200 rounded-lg flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded-lg w-full" />
                  <div className="h-3 bg-gray-100 rounded-lg w-1/3" />
                </div>
              </div>
            ))}
          </div>
        ) : error && news.length === 0 ? (
          <div className="p-8 text-center">
            <AlertCircle className="w-10 h-10 text-orange-300 mx-auto mb-3" />
            <p className="text-gray-500 text-sm">{error}</p>
            <button onClick={() => fetchNews(true)} className="mt-3 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-orange-50 text-orange-600 text-sm font-bold hover:bg-orange-100">
              <RefreshCw className="w-4 h-4" />다시 시도
            </button>
          </div>
        ) : (
          news.map((item, idx) => (
            <a key={`${item.link}-${idx}`} href={item.link} target="_blank" rel="noopener noreferrer"
              className="flex items-start gap-3 p-4 hover:bg-orange-50/50 transition-colors group">
              <div className={`flex-shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                idx < 3 ? 'bg-gradient-to-br from-orange-400 to-amber-500 text-white shadow-sm' : 'bg-gray-100 text-gray-400'
              }`}>{idx + 1}</div>
              <div className="flex-1 min-w-0">
                <h4 className="text-sm font-semibold text-gray-800 group-hover:text-orange-600 transition-colors line-clamp-2 leading-snug mb-1.5">
                  {item.title}
                </h4>
                <div className="flex items-center gap-2 text-[11px] text-gray-400 flex-wrap">
                  <span className="px-1.5 py-0.5 rounded bg-orange-100 text-orange-700 text-[9px] font-bold">암호화폐</span>
                  {item.source && <span className="font-medium text-gray-500">{item.source}</span>}
                  {item.parsedDate > 0 && (
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{timeAgo(item.parsedDate)}</span>
                  )}
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-gray-300 group-hover:text-orange-400 flex-shrink-0 mt-0.5" />
            </a>
          ))
        )}
      </div>

      {news.length > 0 && (
        <div className="px-5 py-3 bg-gray-50 border-t border-gray-100">
          <div className="flex items-center justify-between">
            <p className="text-[10px] text-gray-400">암호화폐·비트코인·블록체인 뉴스 필터링 · 최신순</p>
            <div className="flex items-center gap-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
              </span>
              <span className="text-[10px] font-semibold text-orange-500">LIVE</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ===== BTC TRADE JOURNAL =====
function BtcJournal({ trades, onSave, onDelete }: { trades: BtcTrade[]; onSave: (t: BtcTrade) => void; onDelete: (id: string) => void }) {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTrade, setEditingTrade] = useState<BtcTrade | null>(null);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'buy' | 'sell'>('all');
  const [sortDir, setSortDir] = useState<'desc' | 'asc'>('desc');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Form
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    coin: 'BTC',
    type: 'buy' as 'buy' | 'sell',
    quantity: 0,
    price: 0,
    memo: '',
  });

  const openNew = () => {
    setEditingTrade(null);
    setForm({ date: new Date().toISOString().slice(0, 10), coin: 'BTC', type: 'buy', quantity: 0, price: 0, memo: '' });
    setIsFormOpen(true);
  };

  const openEdit = (trade: BtcTrade) => {
    setEditingTrade(trade);
    setForm({ date: trade.date, coin: trade.coin, type: trade.type, quantity: trade.quantity, price: trade.price, memo: trade.memo });
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.coin || form.quantity <= 0 || form.price <= 0) return;
    const trade: BtcTrade = {
      id: editingTrade?.id || generateId(),
      ...form,
    };
    onSave(trade);
    setIsFormOpen(false);
    setEditingTrade(null);
  };

  const filtered = trades
    .filter(t => {
      if (typeFilter !== 'all' && t.type !== typeFilter) return false;
      if (search) {
        const s = search.toLowerCase();
        return t.coin.toLowerCase().includes(s) || t.memo.toLowerCase().includes(s);
      }
      return true;
    })
    .sort((a, b) => sortDir === 'desc' ? b.date.localeCompare(a.date) : a.date.localeCompare(b.date));

  // Summary
  const totalBuy = trades.filter(t => t.type === 'buy').reduce((s, t) => s + t.price * t.quantity, 0);
  const totalSell = trades.filter(t => t.type === 'sell').reduce((s, t) => s + t.price * t.quantity, 0);
  const pnl = totalSell - (totalBuy > 0 ? totalBuy * (trades.filter(t => t.type === 'sell').reduce((s, t) => s + t.quantity, 0) / Math.max(trades.filter(t => t.type === 'buy').reduce((s, t) => s + t.quantity, 0), 1)) : 0);

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl p-4 text-white">
          <p className="text-xs opacity-80 mb-1">총 매수</p>
          <p className="text-lg font-bold">{formatNumber(Math.round(totalBuy))}원</p>
        </div>
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-4 text-white">
          <p className="text-xs opacity-80 mb-1">총 매도</p>
          <p className="text-lg font-bold">{formatNumber(Math.round(totalSell))}원</p>
        </div>
        <div className={`bg-gradient-to-br ${pnl >= 0 ? 'from-green-500 to-green-600' : 'from-orange-500 to-orange-600'} rounded-2xl p-4 text-white`}>
          <p className="text-xs opacity-80 mb-1">실현 손익</p>
          <p className="text-lg font-bold">{pnl >= 0 ? '+' : ''}{formatNumber(Math.round(pnl))}원</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="코인명, 메모 검색..." className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-300 bg-white" />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-400" />
          {(['all', 'buy', 'sell'] as const).map(type => (
            <button key={type} onClick={() => setTypeFilter(type)}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                typeFilter === type
                  ? type === 'buy' ? 'bg-red-500 text-white' : type === 'sell' ? 'bg-blue-500 text-white' : 'bg-orange-500 text-white'
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}>
              {type === 'all' ? '전체' : type === 'buy' ? '매수' : '매도'}
            </button>
          ))}
          <button onClick={() => setSortDir(d => d === 'desc' ? 'asc' : 'desc')}
            className="p-2 rounded-xl hover:bg-gray-100 text-gray-400">
            {sortDir === 'desc' ? <ChevronDown className="w-4 h-4" /> : <ChevronUp className="w-4 h-4" />}
          </button>
          <button onClick={openNew}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-orange-400 to-amber-500 text-white text-sm font-bold shadow-lg hover:shadow-xl transition-all">
            <Plus className="w-4 h-4" />기록 추가
          </button>
        </div>
      </div>

      <p className="text-sm text-gray-400">총 <span className="font-bold text-gray-600">{filtered.length}</span>건</p>

      {/* Trade list */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <div className="text-5xl mb-4">₿</div>
          <p className="text-gray-500 font-semibold mb-2">{trades.length === 0 ? '아직 매매 기록이 없습니다' : '검색 결과가 없습니다'}</p>
          {trades.length === 0 && (
            <button onClick={openNew} className="mt-4 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-orange-400 to-amber-500 text-white font-bold shadow-lg">
              <Plus className="w-5 h-5" />첫 매매 기록 추가
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(trade => {
            const amount = trade.price * trade.quantity;
            return (
              <div key={trade.id} className="bg-white rounded-2xl shadow-sm border border-gray-100 p-4 hover:shadow-md transition-all group">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                      trade.type === 'buy' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                    }`}>{trade.type === 'buy' ? '매수' : '매도'}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <BtcIcon className="w-4 h-4 text-orange-500" />
                        <p className="font-bold text-gray-800">{trade.coin}</p>
                      </div>
                      <p className="text-xs text-gray-400">{trade.date}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => openEdit(trade)} className="p-1.5 rounded-lg hover:bg-indigo-50 text-gray-400 hover:text-indigo-500"><Edit2 className="w-4 h-4" /></button>
                    {deleteConfirm === trade.id ? (
                      <div className="flex gap-1">
                        <button onClick={() => { onDelete(trade.id); setDeleteConfirm(null); }} className="px-2 py-1 rounded-lg bg-red-500 text-white text-xs font-bold">삭제</button>
                        <button onClick={() => setDeleteConfirm(null)} className="px-2 py-1 rounded-lg bg-gray-200 text-gray-600 text-xs font-bold">취소</button>
                      </div>
                    ) : (
                      <button onClick={() => setDeleteConfirm(trade.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <span className="text-gray-400 text-xs">수량</span>
                    <p className="font-semibold">{trade.quantity}</p>
                  </div>
                  <div>
                    <span className="text-gray-400 text-xs">단가</span>
                    <p className="font-semibold">{formatNumber(trade.price)}원</p>
                  </div>
                  <div>
                    <span className="text-gray-400 text-xs">금액</span>
                    <p className={`font-bold ${trade.type === 'buy' ? 'text-red-600' : 'text-blue-600'}`}>
                      {formatNumber(Math.round(amount))}원
                    </p>
                  </div>
                </div>
                {trade.memo && (
                  <div className="mt-2 bg-gray-50 rounded-lg p-2">
                    <p className="text-xs text-gray-600">📝 {trade.memo}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                <BtcIcon className="w-5 h-5 text-orange-500" />
                {editingTrade ? '매매 기록 수정' : '새 매매 기록'}
              </h2>
              <button onClick={() => setIsFormOpen(false)} className="p-2 hover:bg-gray-100 rounded-xl"><X className="w-5 h-5 text-gray-400" /></button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Type */}
              <div className="grid grid-cols-2 gap-2">
                <button type="button" onClick={() => setForm(f => ({ ...f, type: 'buy' }))}
                  className={`py-3 rounded-xl font-bold text-sm transition-all ${form.type === 'buy' ? 'bg-red-500 text-white shadow-lg' : 'bg-gray-100 text-gray-500'}`}>매수</button>
                <button type="button" onClick={() => setForm(f => ({ ...f, type: 'sell' }))}
                  className={`py-3 rounded-xl font-bold text-sm transition-all ${form.type === 'sell' ? 'bg-blue-500 text-white shadow-lg' : 'bg-gray-100 text-gray-500'}`}>매도</button>
              </div>

              {/* Date */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">날짜</label>
                <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-300" />
              </div>

              {/* Coin */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">코인</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {COINS.slice(0, 6).map(c => (
                    <button key={c.symbol} type="button" onClick={() => setForm(f => ({ ...f, coin: c.symbol }))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                        form.coin === c.symbol ? 'bg-orange-500 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                      }`}>{c.symbol}</button>
                  ))}
                </div>
                <input type="text" value={form.coin} onChange={e => setForm(f => ({ ...f, coin: e.target.value.toUpperCase() }))}
                  placeholder="기타 코인 직접 입력" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-300" />
              </div>

              {/* Qty & Price */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">수량</label>
                  <input type="number" step="any" value={form.quantity || ''} onChange={e => setForm(f => ({ ...f, quantity: Number(e.target.value) }))}
                    placeholder="0" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-300" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">단가 (원)</label>
                  <input type="number" value={form.price || ''} onChange={e => setForm(f => ({ ...f, price: Number(e.target.value) }))}
                    placeholder="0" className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-300" />
                </div>
              </div>

              {/* Amount */}
              <div className="bg-gray-50 rounded-xl p-4 flex justify-between">
                <span className="font-semibold text-gray-700">{form.type === 'buy' ? '총 매수 금액' : '총 매도 금액'}</span>
                <span className={`font-bold text-lg ${form.type === 'buy' ? 'text-red-600' : 'text-blue-600'}`}>
                  {formatNumber(Math.round(form.quantity * form.price))}원
                </span>
              </div>

              {/* Memo */}
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">메모</label>
                <textarea value={form.memo} onChange={e => setForm(f => ({ ...f, memo: e.target.value }))}
                  placeholder="매매 사유, 전략 등..." rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-orange-300 resize-none" />
              </div>

              <button type="submit" className={`w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all ${
                form.type === 'buy' ? 'bg-gradient-to-r from-red-500 to-red-600' : 'bg-gradient-to-r from-blue-500 to-blue-600'
              }`}>
                {editingTrade ? '수정 완료' : form.type === 'buy' ? '매수 기록 추가' : '매도 기록 추가'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

// ===== MAIN COMPONENT =====
export function Bitcoin({ trades, onSaveTrade, onDeleteTrade, isDark = false }: BitcoinProps) {
  const [subTab, setSubTab] = useState<SubTab>('chart');

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
          <BtcIcon className="w-6 h-6 text-orange-500" /> 비트코인
        </h2>
        <p className="text-sm text-gray-400 mt-1">업비트 차트, 암호화폐 뉴스, 매매 일지를 관리하세요</p>
      </div>

      {/* Sub tabs */}
      <div className="flex gap-1 bg-white/60 p-1 rounded-xl border border-gray-100">
        {[
          { id: 'chart' as SubTab, label: '업비트 차트', icon: <BarChart3 className="w-4 h-4" /> },
          { id: 'news' as SubTab, label: '암호화폐 뉴스', icon: <Newspaper className="w-4 h-4" /> },
          { id: 'journal' as SubTab, label: '매매 일지', icon: <TrendingUp className="w-4 h-4" /> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setSubTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all flex-1 justify-center ${
              subTab === tab.id
                ? 'bg-gradient-to-r from-orange-400 to-amber-500 text-white shadow-lg shadow-orange-200'
                : 'text-gray-500 hover:bg-gray-100'
            }`}
          >
            {tab.icon}{tab.label}
          </button>
        ))}
      </div>

      {subTab === 'chart' && <UpbitChart isDark={isDark} />}
      {subTab === 'news' && <CryptoNewsFeed />}
      {subTab === 'journal' && <BtcJournal trades={trades} onSave={onSaveTrade} onDelete={onDeleteTrade} />}
    </div>
  );
}
